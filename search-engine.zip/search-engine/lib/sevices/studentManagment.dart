//import 'package:flutter/material.dart';
//import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:flutter_app/UI/QuranWidgets.dart';
//class StudentManagement {
//
//  storeNewStudent(user, context, name, currentItemSelected) {
//    Firestore.instance.collection('/students').add({
//      'uid' : user.uid,
//      'name' : name,
//      'email': user.email,
//      'type' : currentItemSelected
//    }).then((value) {
//      Navigator.of(context).pop();
//      Navigator.push(context, MaterialPageRoute(builder: (context) => AllQuran()));
//     // ProfilePage(user: user);
//    }).catchError((e) {
//      print(e);
//    });
//  }
//
//  getAllStudent() async {
//    return  await Firestore.instance.collection('students').getDocuments();
//  }
//}
